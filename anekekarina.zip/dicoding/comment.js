function kirim() {
     var a=document.getElementById("abc").innerHTML;
     var b=document.getElementById("text").value;
     var c=document.getElementById("k").value;
     document.write(a + "<br />" + "<br />");
     document.write(b + "<br />");
     document.write(c);
  }